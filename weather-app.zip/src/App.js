import "./App.scss";
import Weather from "./components/weather/Weather";

function App() {
  return (
    <div>
      <Weather />
    </div>
  );
}

export default App;
